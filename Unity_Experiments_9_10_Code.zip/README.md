# Unity Computer Graphics Experiments 9–10

## Experiment 9 — Interactive 3D Scene
Open `Experiment_9_Unity_Interactive_3D_Scene` in Unity or copy `Interactive3DScene.cs` into a Unity project's `Assets` folder. Attach the script to an empty GameObject and press Play.

Controls:
- WASD: move
- Mouse: look around
- Space: jump
- Q / E: rotate left / right

## Experiment 10 — 3D Viewing Pipeline
Copy `ViewingPipelineDemo.cs` into a Unity project's `Assets` folder. Attach it to an empty GameObject and press Play.

Controls:
- P: perspective projection
- O: orthographic projection
- V: toggle full-screen/inset viewport
- Arrow keys: orbit the camera around the object

These scripts create their demonstration objects at runtime. They use Unity's built-in input axes and the legacy `Input` API; if the project is configured for the new Input System only, set Active Input Handling to **Both** or **Input Manager (Old)** in Player Settings.
